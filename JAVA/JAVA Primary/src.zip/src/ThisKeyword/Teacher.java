package ThisKeyword;

public class Teacher {
    String name, qualification;
    int id;
    Teacher(String name, int id) {
        this.name = name;
        this.id = id;
    }
    void dis() {
        System.out.println("Name : " + name);
        System.out.println("ID : " + id);
    }
    Teacher(String name, String qualification, int id) {
        this(name, id);
        this.qualification = qualification; 
    }
    void display() {
        this.dis();
        System.out.println("Qualification : " + qualification);
    }
}
