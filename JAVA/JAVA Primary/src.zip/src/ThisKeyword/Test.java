package ThisKeyword;

public class Test {

    public static void main(String[] args) {
        Teacher ob1 = new Teacher("Rahatul Islam", "Engineer", 203);
        Teacher ob2 = new Teacher("Sohanur Rahman", 204);
        ob1.display();
        ob2.display();
       
    }
}
