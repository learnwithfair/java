package PolymorphismCompileTime;

public class Test {

    public static void main(String[] args) {
        NewClass ob = new NewClass();
        ob.add();
        ob.add(6.5, 5.6);
        ob.add(5, 10, 20);
    }
}
