package Abstract2;
public class Test {
    public static void main(String[] args) {
        CashMoney ob1;
        //ob1=new Rahim();//Wrong
        ob1=new Rahim() {
            @Override
            void SendMoney() {
                System.out.println("This is Anonymous Class");
            }
        };
        ob1.SendMoney();
        ob1.call();
        ob1=new Karim();
        ob1.call();
    }
}
