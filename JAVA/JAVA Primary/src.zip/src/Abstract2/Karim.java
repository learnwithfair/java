package Abstract2;

public class Karim extends CashMoney {
@Override
void SendMoney()
{
     super.call();
}
    @Override
    void call() {
        this.SendMoney();
        System.out.println("I want to  3000 TK");
    }
}
