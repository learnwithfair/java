package Abstract2;

abstract public class CashMoney {

    abstract void SendMoney();

    void call() {
        System.out.println("Hello");
    }
}
