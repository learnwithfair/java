package Abstract2;

abstract public class Rahim extends CashMoney {

    @Override
    void call() {
        super.call();
        System.out.println("I want to  2000 TK");
    }
}
