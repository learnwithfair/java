package TypeCasting;

public class Person {

    void display() {
        System.out.println("This is Person Class");
    }
}
