package TypeCasting;

public class Teacher extends Person {

    @Override
    void display() {
        System.out.println("This is Teacher Class");
    }
}
