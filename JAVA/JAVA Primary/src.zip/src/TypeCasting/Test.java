package TypeCasting;

public class Test {

    public static void main(String[] args) {
        Person p = new Teacher();//UpCasting
        p.display();
        Teacher t = (Teacher) new Person();//DownCasting
        t.display();
    }
}
