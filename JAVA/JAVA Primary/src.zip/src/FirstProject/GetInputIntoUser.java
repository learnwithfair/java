package FirstProject;

import java.util.Scanner;

public class GetInputIntoUser {

    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        float r=23.42f;
        System.out.printf("%f\n",r);
        System.out.printf("Enter any String  : ");
        String num = Rahat.nextLine();
        System.out.printf("Enter any Interger number  : ");
        int num1= Rahat.nextInt();
        System.out.printf("Enter any Character Case  : ");
        char num2 = Rahat.next().charAt(0);
        System.out.printf("Enter any float number  : ");
        float num4 = Rahat.nextFloat();
        System.out.printf("Enter any double number  : ");
        double num5 = Rahat.nextDouble();
        

    }
}
