
package FirstProject;
/**
 *
 * @author MD RAHATUL ISLAM
 */
public class BasicStructure {
    public static void main(String[] args) {
        System.out.println("Hello Word");
    }
}

