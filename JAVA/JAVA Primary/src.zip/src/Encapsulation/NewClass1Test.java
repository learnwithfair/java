package Encapsulation;

import java.util.Scanner;

public class NewClass1Test {

    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        NewClass1 ob = new NewClass1();
        System.out.printf("Enter Name  : ");
        String name = Rahat.nextLine();
        System.out.printf("Enter ID  : ");
        int id = Rahat.nextInt();
        ob.setName(name);
        ob.setId(id);
        System.out.print("Name : " + ob.getName());
        System.out.println("\tID : " + ob.getId());
        //ob.display();
    }
}
