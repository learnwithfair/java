
package Encapsulation;

public class NewClass {
    String name;
    int id;
    NewClass(String name,int id)
    {
        this.name=name;
        this.id=id;
    }
    void display()
    {
        System.out.println("Name : "+name+"\tID : "+id);
    }
}
