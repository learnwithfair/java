
package Encapsulation;

import java.util.Scanner;

public class NewClassTest {
    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        System.out.printf("Enter name  : ");
        String name=Rahat.nextLine();
        System.out.printf("Enter ID  : ");
        int id=Rahat.nextInt();
        NewClass ob=new NewClass(name,id);
        ob.display();
    }
}
