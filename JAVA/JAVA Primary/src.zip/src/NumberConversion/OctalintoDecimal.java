
package NumberConversion;

import java.util.Scanner;

public class OctalintoDecimal {
    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        System.out.printf("Enter any Binary Number : ");
        String binary = Rahat.next();
        System.out.printf("Enter any Octal Number : ");
        String octal = Rahat.next();
        System.out.printf("Enter any Hexadecimal Number : ");
        String hex = Rahat.next();
        int dml1 = Integer.parseInt(binary, 2);
        System.out.println("\n\nBinary to Decimal Number is : " + dml1);
        int dml2 = Integer.parseInt(octal, 8);
        System.out.println("Octal to Decimal Number is : " + dml2);
        int dml = Integer.parseInt(hex, 16);
        System.out.println("Hexadecimal to Decimal Number is : " + dml);
    }
}
