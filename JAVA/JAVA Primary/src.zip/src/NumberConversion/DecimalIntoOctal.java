
package NumberConversion;

import java.util.Scanner;

public class DecimalIntoOctal {
    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
         while (true) {
            System.out.printf("Enter any Decimal number  : ");
            int dml = Rahat.nextInt();
           String bin = Integer.toBinaryString(dml);
            System.out.println("Binary  number is : "+bin);
            String oct=Integer.toOctalString(dml);
            System.out.println("Octal number is : "+oct);
            String hex=Integer.toHexString(dml);
            System.out.println("Hexadecimal number is : "+hex);
        }
    }
}
