
package ToStringMethod;

public class NewClass {
    String name;
    int age;
    NewClass(String name,int age)
    {
        this.name=name;
        this.age=age;
    }
    @Override
    public String toString()
    {
        return "Name : "+name+"\nAge : "+age;
    }
}
