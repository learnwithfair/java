
package ToStringMethod;

public class Test {
    public static void main(String[] args) {
        NewClass ob1 =new NewClass("Rahatul Islam",22);
        NewClass ob2 =new NewClass("Imran Hosain",23);
        System.out.println(ob1);
        System.out.println(ob2);
    }
}
