package Loop;

import java.util.ArrayList;

public class Iterator {

    public static void main(String[] args) {
        ArrayList<Integer> number = new ArrayList<>();
        number.add(34);
        number.add(43);
        number.add(65);
        number.add(98);
        number.add(65);

        System.out.printf("ArrayList : [");
        java.util.Iterator count = number.iterator();
        while (count.hasNext()) {
            System.out.print(" " + count.next());
        }
        System.out.println(" ]");
    }
}
