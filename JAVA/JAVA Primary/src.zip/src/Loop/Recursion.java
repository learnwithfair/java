package Loop;
import java.util.Scanner;
public class Recursion {
    public static int fact(int n) {
        if (n == 1) {
            return 1;
        } else {
            return n * fact(n - 1);
        }
    }
    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        System.out.printf("Enter any number  : ");
        int n = Rahat.nextInt();
        System.out.println("Factorial value is : " + fact(n));
    }
}
