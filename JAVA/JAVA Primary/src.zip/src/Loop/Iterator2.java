package Loop;
import java.util.ArrayList;
import java.util.Iterator;

public class Iterator2 {
    public static void main(String[] args) {
       ArrayList<Integer> number = new ArrayList<Integer>();
       
      number.add(56);
       number.add(54);
       number.add(98);
       number.add(58);
       number.add(33);
        System.out.printf("Array List  : [");
        Iterator num=number.iterator();
        while(num.hasNext())
        {
            System.out.print(" "+num.next());
        }
        System.out.println(" ]");
    }
}
