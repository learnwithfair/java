package Loop;

import java.util.Scanner;

public class ForEachLoop {

    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        System.out.printf("How many number  : ");
        int n = Rahat.nextInt();
        int[] array = new int[n];
        System.out.printf("Enter Elements : ");
        for (int i = 0; i < n; i++) {
            array[i] = Rahat.nextInt();
        }
        System.out.printf("Array List : ");
        for (int i : array) {
            System.out.print(" " + i);
        }
        System.out.println();
    }
}

