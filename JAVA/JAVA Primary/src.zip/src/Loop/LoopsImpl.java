
package Loop;


public class LoopsImpl extends Loops {
    
}
