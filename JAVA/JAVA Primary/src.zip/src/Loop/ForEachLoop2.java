package Loop;
public class ForEachLoop2 {
    public static void main(String[] args) {
        int[] array = {2,3,4,6,3};
        for (int i : array) {
            System.out.println(" "+i);
        }
    }
}
