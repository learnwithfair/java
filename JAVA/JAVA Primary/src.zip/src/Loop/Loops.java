package Loop;
import java.util.Scanner;
public class Loops {
   public static void dis(int n) {
        for (int i = 1; i <= n; i++) {
            if (i == n) {
                System.out.printf("%d = ", i);
            } else {
                System.out.printf("%d + ", i);
            }
        }
    }
    public static void main(String[] args) {

        Scanner Rahat = new Scanner(System.in);
        System.out.printf("How many number : ");
        int n = Rahat.nextInt();
        int sum, i;
        sum = 0;
        System.out.printf("Using for Loop Sumastion of number 1 to %d : \n",n);
        for (i = 1; i <= n; i++) {
            sum = sum + i;
        }
        dis(n);
        System.out.println(sum);
        i = 1;
        sum = 0;
        System.out.printf("Using while Loop Sumastion of number 1 to %d : \n",n);
        while (i <= n) {
            sum = sum + i;
            i++;
        }
        dis(n);
        System.out.println(sum);
        i = 1;
        sum = 0;
        System.out.printf("Using do while Loop Sumastion of number 1 to %d : \n",n);
        do {
            sum = sum + i;
            i++;
        } while (i <= n);
        dis(n);
        System.out.println(sum);
    }
}
