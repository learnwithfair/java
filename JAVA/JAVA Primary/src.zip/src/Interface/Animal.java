package Interface;

public interface Animal {
    /*public static final */int x=20;
    void eat();
}
