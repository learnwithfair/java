package Interface;

public class Test {

    public static void main(String[] args) {
        Animal ob;
        ob = new Cat();
        ob.eat();
        ob = new Dog();
        ob.eat();
        System.out.println("Value of X : "+ Animal.x);
    }
}
