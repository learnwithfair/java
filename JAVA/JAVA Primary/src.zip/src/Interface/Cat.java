package Interface;

public class Cat implements Animal {

    @Override
    public void eat() {
        //x=30;//it's Wrong because it's final variable
        System.out.println("Cat can eat fish");
        System.out.println("X : "+x);
    }
}
