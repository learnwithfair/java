
package MultilevelInheritance;

public class Teacher {
    String name;
    Teacher(String name)
    {
        this.name=name;
    }
    void display()
    {
        System.out.print("Name :"+name);
    }
}
