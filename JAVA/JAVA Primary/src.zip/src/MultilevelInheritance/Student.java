
package MultilevelInheritance;

public class Student extends Teacher{
    int id;
    Student(String name,int id)
    {
        super(name);
        this.id=id;
    }
    @Override
    void display()
    {
        super.display();
        System.out.print("  ID : "+id);
    }
}
