
package MultilevelInheritance;

public class Rohim extends Student {
    double gpa;
    Rohim(String name,int id,double gpa)
    {
        super(name,id);
        this.gpa=gpa;
    }
    @Override
    void display()
    {
        super.display();
        System.out.println("  GPA : "+gpa);
    }
}
