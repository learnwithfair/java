
package MultilevelInheritance;

public class Test {
    public static void main(String[] args) {
        Rohim ob =new Rohim("Rahatul Islam",203,4.63);
        ob.display();
    }
}
