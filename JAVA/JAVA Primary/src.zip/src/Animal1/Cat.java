package Animal1;
//import Animal.*;//All Class Called
//import Animal2.Dog;//Single Class Called
public class Cat {

    public static void main(String[] args) {
        Dog dog1 = new Dog();
        Animal2.Dog dog2 = new Animal2.Dog();
        Animal3.Dog dog3 = new Animal3.Dog();
        dog1.display();
        dog2.display();
        dog3.display();
    }
}
