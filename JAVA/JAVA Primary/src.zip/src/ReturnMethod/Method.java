package ReturnMethod;

import java.util.Scanner;

public class Method {

    String name;
    int age;

    Method(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String Method() {
        return "Name : " + name + "\tAge : " + age;
    }

    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        System.out.printf("How many Student : ");
        int n = Rahat.nextInt();
        System.out.printf("Enter Name & Age : \n");
        Method[] ob = new Method[n];
        //String[] name=new String[n];
        for (int i = 0; i < n; i++) {
            System.out.printf("%d.Name  : ", i + 1);
            String name = Rahat.next();
            System.out.printf("%d.Age  : ", i + 1);
            int age = Rahat.nextInt();
            ob[i] = new Method(name, age);
        }
        for (int i = 0; i < n; i++) {
            System.out.println(ob[i].Method());
        }
    }
}
