package Abstract;

public class Test {

    public static void main(String[] args) {
        MobileUser ob;
        ob = new Rahim();
        ob.SendMessage();
        ob = new Karim();
        ob.SendMessage();
    }
}
