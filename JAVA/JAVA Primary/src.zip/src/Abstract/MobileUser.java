package Abstract;

abstract public class MobileUser {

    abstract void SendMessage();
}
