package Abstract;

public class Rahim extends MobileUser {

    @Override
    void SendMessage() {
        System.out.println("Hi, This is Rahim");
    }
}
