package Abstract;

public class Karim extends MobileUser {

    @Override
    void SendMessage() {
        System.out.println("Hi, This is Karim");
    }
}
