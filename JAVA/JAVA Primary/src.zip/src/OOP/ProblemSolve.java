

package OOP;

public class ProblemSolve {
    double height,width,depth;
    static int count=0;
    ProblemSolve(double height,double width,double depth)
    {
        this.height=height;
        this.width=width;
        this.depth=depth;
    }
    void displayVol()
    {
        count++;
        System.out.println("Volume of "+count+" number box is : "+height*width*depth);
    }
}
