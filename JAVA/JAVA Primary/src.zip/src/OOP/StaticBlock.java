package OOP;

public class StaticBlock {
    static String name;
    static int id;
    //at First Static Block Call hoy then another
    static {
        name = "Rahatul Islam";
        id = 203;
        dis();
    }
    static  void dis() {
        System.out.println("Name : " + name + "\tID : " + id);
    }
    static {
        System.out.println("I am a BSc Engineering Student");
        name = "Anisul Islam";
        id = 204;
    }
    void dis2() {
        System.out.println("Name : " + name + "\tID : " + id);
    }
}
