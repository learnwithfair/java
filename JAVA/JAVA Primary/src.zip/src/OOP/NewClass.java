
package OOP;

import java.util.Scanner;

public class NewClass {
    String name;
    int ID;
    static int count=0;
    NewClass(String name,int ID)
    {
        this.name=name;
        this.ID=ID;
    }
    void dis()
    {
        count++;
        System.out.print(count+". Name : "+name);
        System.out.println("\tID : "+ID);
    }
    public static void main(String[] args) {
       Scanner Rahat = new Scanner(System.in);
        String[] name = new String[4];
        int[] ID = new int[4];
        System.out.printf("How many Student number : ");
        int n=Rahat.nextInt();
        System.out.printf("Enter Name & ID : ");
        for (int i = 0; i < n; i++) {
            System.out.printf("\n%d. Name : ", i + 1);
            name[i] = Rahat.next();
            
            System.out.printf("\n%d. ID : ",i+1);
            ID[i]=Rahat.nextInt();

        }
        for (int i = 0; i < n; i++) {
            NewClass r=new NewClass(name[i],ID[i]);
            r.dis();
        }
    }
}
