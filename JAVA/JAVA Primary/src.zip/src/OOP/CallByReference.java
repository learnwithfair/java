
package OOP;

public class CallByReference {
    String name;
    void dis(CallByReference n)
    {
        n.name="Sohanur Rahman";
    }
}
