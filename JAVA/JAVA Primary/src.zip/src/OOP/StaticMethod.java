package OOP;

public class StaticMethod {
    static void display()
    {
        
        System.out.println("I am static method");
    }
    
    void display2()
    {
        System.out.println("I am non-static method");
    }
    
}
