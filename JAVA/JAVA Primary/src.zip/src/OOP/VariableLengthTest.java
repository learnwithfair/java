package OOP;

public class VariableLengthTest {

    public static void main(String[] args) {
        VariableLength r = new VariableLength();
        r.dis(20, 30);
        r.dis(20, 30, 40);
        r.dis(20, 30, 40, 50);
        r.dis(20, 30, 40, 50, 60.5);
    }
}
