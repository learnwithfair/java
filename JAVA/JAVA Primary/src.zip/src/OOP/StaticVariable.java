package OOP;

public class StaticVariable {

    String name;
    int id;
    static int age;

    StaticVariable(String name, int id, int age) {
        this.name = name;
        this.id = id;
        this.age = age;
    }

    void dis() {
        System.out.print("Name : " + name);
        System.out.println("\tID : " + id + "\tAge : " + age);
    }
}
