package OOP;

public class ProblemSolveTest {

    public static void main(String[] args) {
        ProblemSolve box1 = new ProblemSolve(10, 10, 10);
        ProblemSolve box2 = new ProblemSolve(20, 30, 10);
        box1.displayVol();
        box2.displayVol();
    }

}
