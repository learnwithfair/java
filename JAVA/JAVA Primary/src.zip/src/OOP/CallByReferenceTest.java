
package OOP;

public class CallByReferenceTest {
    public static void main(String[] args) {
        CallByReference r=new CallByReference();
        r.name="Rahatul Islam";
        System.out.println("Before Calling Function Name : "+r.name);
        r.dis(r);
        System.out.println("After Calling Function Name : "+r.name);
    }
}
