package OOP;

public class StaticMethodTest {

    public static void main(String[] args) {
        StaticMethod r = new StaticMethod();
        StaticMethod.display();
        r.display2();
    }
}
