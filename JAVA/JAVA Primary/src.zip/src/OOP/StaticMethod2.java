package OOP;

public class StaticMethod2 {

    int x = 20;
    static int x2 = 30;

    void display() {
        System.out.println("I am Non-Static Method");
        System.out.println("X : " + x);
        System.out.println("X2 : " + x2);
        display2();
    }

    static void display2() {
        //display();//Not Currect
        // System.out.println("X : "+x);//Not Currect
        System.out.println("I am Static Method");
        System.out.println("X2 : " + x2);
    }
}
