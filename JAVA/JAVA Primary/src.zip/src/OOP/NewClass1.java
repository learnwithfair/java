
package OOP;

public class NewClass1 {
    String name;
    int ID;
    static int count=0;
    NewClass1(String name,int ID)
    {
        this.name=name;
        this.ID=ID;
    }
    NewClass1()
    {
        System.out.println("I am default constructor");
    }
    void dis()
    {
        count++;
        System.out.print(count+". Name : "+name);
        System.out.println("\tID : "+ID);
    }
}
