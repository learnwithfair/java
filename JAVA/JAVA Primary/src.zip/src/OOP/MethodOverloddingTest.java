package OOP;

public class MethodOverloddingTest {

    public static void main(String[] args) {
        MethodOverlodding r = new MethodOverlodding();
        System.out.println("\n\nFirst Function call");
        r.dis();
        System.out.println("\n\nSecond Function call");
        r.dis("Rahatul Islam", 203);
        System.out.println("\n\nThird Function call");
        r.dis("Rahatul Islam", 203, 22);
        System.out.println("\n\nFourth Function call");
        r.dis("Rahatul Islam", 203, 22, 4.63);
    }
}
