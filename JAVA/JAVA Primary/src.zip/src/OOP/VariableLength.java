package OOP;

public class VariableLength {
    void dis(double... num) {
        double sum = 0;
        for (double d : num) {
            sum = sum + d;
        }
        System.out.println("Sum of Value is : " + sum);
    }
    public static void main(String[] args) {
        VariableLength r = new VariableLength();
        r.dis(20, 30);
        r.dis(20, 30, 40);
        r.dis(20, 30, 40, 50);
        r.dis(20, 30, 40, 50, 60.5);
    }
}
