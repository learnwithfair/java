package OOP;

import java.util.Scanner;

public class NewClass1Test {

    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        String[] name = new String[4];
        int[] ID = new int[4];
        System.out.printf("How many Student : ");
        int n = Rahat.nextInt();
        System.out.printf("Enter name & ID: ");
        for (int i = 0; i < n; i++) {
            System.out.printf("\n%d.Name  : ", i + 1);
            name[i] = Rahat.next();
            System.out.printf("\n%d.ID  : ", i + 1);
            ID[i] = Rahat.nextInt();
        }
        System.out.println("\n\n");
        NewClass1 r1 = new NewClass1();
        for (int i = 0; i < n; i++) {
            NewClass1 r = new NewClass1(name[i], ID[i]);
            r.dis();
        }
    }
}
