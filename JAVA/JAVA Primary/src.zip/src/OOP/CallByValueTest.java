
package OOP;

public class CallByValueTest {
    public static void main(String[] args) {
        CallByValue r=new CallByValue();
        int x=30;
        System.out.println("Before Calling Function X = "+x);
        r.dis(x);
        System.out.println("After Calling Function X = "+x);
    }
}
