package OOP;

public class StaticVariableTest {

    public static void main(String[] args) {
        StaticVariable r = new StaticVariable("Rahatul Islam", 202, 21);
        r.dis();
        StaticVariable r2 = new StaticVariable("Anisul Islam", 203, 27);
        //Count hisaber moto defferent defferent place ney na
        StaticVariable r3 = new StaticVariable("Sohanur Rohman", 204, 22);
        r2.dis();
        r3.dis();
    }
}
