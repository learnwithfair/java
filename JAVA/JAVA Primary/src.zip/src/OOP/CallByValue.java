
package OOP;

public class CallByValue {
   void dis(int x) 
   {
       x=20;
       System.out.println("Function is called");
   }
}
