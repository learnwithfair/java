package OOP;

public class MethodOverlodding {

    void dis() {
        System.out.println("Nothing to add");
    }

    void dis(String name, int id) {
        System.out.println("Name : " + name);
        System.out.println("ID : " + id);
    }

    void dis(String name, int id, int age) {
        System.out.println("Name : " + name);
        System.out.println("ID : " + id);
        System.out.println("Age : " + age);
    }

    void dis(String name, int id, int age, double gpa) {
        System.out.println("Name : " + name);
        System.out.println("ID : " + id);
        System.out.println("Age : " + age);
        System.out.println("GPA : " + gpa);
    }
}
