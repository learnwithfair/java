package OOP;

public class StaticMethod2Test {

    public static void main(String[] args) {
        StaticMethod2 r = new StaticMethod2();
        r.display();
        //r.display2();
        //Or
        StaticMethod2.display2();
    }
}
