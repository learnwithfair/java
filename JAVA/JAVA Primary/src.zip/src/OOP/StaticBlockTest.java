package OOP;

public class StaticBlockTest {

    public static void main(String[] args) {
        System.out.println("Static Block Call");
        StaticBlock r = new StaticBlock();
        System.out.println("Function Call");
        StaticBlock.dis();
        //Or
        //  r.dis();
        r.dis2();

    }
}
