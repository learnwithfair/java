package String;

public class StringBuilderDemo1 {

    public static void main(String[] args) {
        String str = "Md : ";
        
        StringBuilder sb = new StringBuilder(str + "Rahatul");
        StringBuilder sb2 = new StringBuilder("B.Sc Eng. Md Sohanur Rahman");
        sb.append(" Islam " + 121);
        System.out.println("Sb1 : " + sb);
        System.out.println("Before Replace sb2 : " + sb2);
        sb2.replace(10, 27, sb.toString());
        System.out.println("After Replace sb2 : " + sb2);
    }
}
