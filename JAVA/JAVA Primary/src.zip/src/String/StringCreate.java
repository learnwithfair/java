package String;

public class StringCreate {

    public static void main(String[] args) {
        String s1 = new String("Rahatul Islam");
        String s2 = "Rahatul Islam";
        char[] s3 = {'R', 'a', 'h', 'a', 't', ' ', 'I', 's', 'l', 'a', 'm'};
        String[] s4 = {"Rahatul", "Rahat", "Ratul", "Raju", "Rabbi"};
        System.out.println("Str1 : " + s1);
        System.out.println("Str2 : " + s2);
        System.out.println("Str3 : " + s1);
        System.out.print("Str4 : ");
        for (String string : s4) {
            System.out.printf("%s ,", string);
        }
        System.out.println();
    }
}
