package String;

public class Method1 {

    public static void main(String[] args) {
        String[] str1 = {"Ratul", "Rahat", "Raju", "Rabbi"};
        String str2 = "Rahatul Islam";
        String str3 = "rahatul islam";
        String str4 = "Bangladesh is my country";
        String str5 = "    Bangladesh    is my country    ";
        String str6 = "";
        System.out.printf("Students List :\nstr1 : ");
        for (String string : str1) {
            System.out.print(string + ", ");
        }
        System.out.println("\nStr2 : " + str2);
        System.out.println("Str3 : " + str3);
        System.out.println("Str4 : " + str4);
        System.out.println("Str5 : " + str5);
        System.out.println("Str6 : " + str6);
        int len = str1.length;
        System.out.println("\nLength of Str1 is : " + len);
        int len2 = str2.length();
        System.out.println("Length of Str2 is : " + len2);
        boolean check2 = str2.equals(str3);
        System.out.println("Str2 & Str3 are Equals : " + check2);
        boolean check1 = str2.equalsIgnoreCase(str3);
        System.out.println("Str2 & Str3 are EqualsIgnore Case : " + check1);
        boolean check3 = str4.contains("country");
        System.out.println("Contain value of country in the str4 : " + check3);
        boolean check4 = str6.isEmpty();
        System.out.println("Str6 is Empty : " + check4);
        String s = str6.concat(str2);
        System.out.println("After concat str2 in Str6 : " + s);
        String s2 = str2.toUpperCase();
        System.out.println("Upper case Str2 : " + s2);
        String s3 = str2.toLowerCase();
        System.out.println("Lower case Str2 : " + s3);
    }
}
