package String;

import java.util.Scanner;

public class StringReverse {

    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        System.out.printf("Enter name : ");
        char[] str = new char[30];
        str = Rahat.nextLine().toCharArray();
        int i;
        int len = str.length;
        System.out.println("Size of Name : " + len);
        for (i = len - 1; i >= 0; i--) {
            System.out.printf("%c ", str[i]);
        }
        System.out.println();
    }
}
