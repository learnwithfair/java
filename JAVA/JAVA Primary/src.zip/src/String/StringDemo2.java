package String;

import java.util.Scanner;

public class StringDemo2 {

    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        System.out.printf("Please Enter Four Students Name : \n");
        String[] str = new String[4];
        for (int i = 0; i < 4; i++) {
            System.out.printf("%d. Name : ", i + 1);
            str[i] = Rahat.nextLine();
        }
        System.out.printf("Students List  : ");
        for (String string1 : str) {
            System.out.print(string1 + ", ");
        }
        System.out.println();
    }
}
