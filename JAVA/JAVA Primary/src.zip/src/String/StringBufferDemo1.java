
package String;

public class StringBufferDemo1 {
    public static void main(String[] args) {
        String str="madam";
        StringBuffer sb=new StringBuffer(str);
        sb.append(" "+121);
        sb.append(" Turna");
        System.out.println("Before Reverse : " +sb);
        sb.setLength(9);
        System.out.println("After Set Length : "+sb);
        sb.delete(5, 10);
        System.out.println("After Delete Index 5 to 9 : "+sb);
        String sb2=sb.reverse().toString();
        System.out.println("After Reverse : "+sb);
        if(sb2.equals(str))
            System.out.println("Palindrom");
        else 
            System.out.println("Not Palindrom");
    }
}
