package String;


public class Method {

    public static void main(String[] args) {
        String[] str1 = {"Ratul","Rahat","Raju","Rabbi"};
        String str2 = "Rahatul Islam";
        String str3 = "rahatul islam";
        String str4 = "Bangladesh is my country";
        String str5 = "    Bangladesh    is my country    ";
        String str6= "";
        System.out.printf("Students List :\nstr1 : ");
        for (String string : str1) {
            System.out.print(string + ", ");
        }
        System.out.println("\nStr2 : " + str2);
        System.out.println("Str3 : " + str3);
        System.out.println("Str4 : " + str4);
        System.out.println("Str5 : " + str5);
        System.out.println("Str6 : " + str6);
        int len = str1.length;
        System.out.println("\nLength of Str1 is : " + len);
        int len2 = str2.length();
        System.out.println("Length of Str2 is : " + len2);
        boolean check2 = str2.equals(str3);
        System.out.println("Str2 & Str3 are Equals : " + check2);
        boolean check1 = str2.equalsIgnoreCase(str3);
        System.out.println("Str2 & Str3 are EqualsIgnore Case : " + check1);
        boolean check3 = str4.contains("country");
        System.out.println("Contain value of country in the str4 : " + check3);
        boolean check4 = str6.isEmpty();
        System.out.println("Str6 is Empty : " + check4);
        String s = str6.concat(str2);
        System.out.println("After concat str2 in Str6 : " + s);
        String s2 = str2.toUpperCase();
        System.out.println("Upper case Str2 : " + s2);
        String s3 = str2.toLowerCase();
        System.out.println("Lower case Str2 : " + s3);
        boolean check5 = str4.startsWith("Bangla");
        System.out.println("Str4 Start With Bangla: " + check5);
        boolean check6 = str4.endsWith("try");
        System.out.println("Str4 ends with try : " + check6);
        char check7 = str2.charAt(0);
        System.out.println("Using charAt Value of 0 index of str2 is : " + check7);
        int check8 = str2.codePointAt(0);
        System.out.println("Using charPointAt   " + check7 + " of str2 Ascii Value  is : " + check8);
        int check9 = str4.indexOf("is");
        System.out.println("Index of 'is' in str4 is : " + check9);
        int check10 = str4.lastIndexOf("n");
        System.out.println("Last Index of 'n' in str4 is : " + check10);
        String s4 = str5.trim();
        System.out.println("After Trim str5 : " + s4);
        String s5=str6.replaceAll(str6,str2);
        System.out.println("After Replace Str5 by str2 : "+s5);
        String s6=str4.replace('a', 'R');
        System.out.println("After Replace Str4 by 'a' alternative 'R'  : "+s6);
        String[] s7=str4.split(" ");
        System.out.printf("After Split by ' ' str4  : \n");
        for (String string : s7) {
            System.out.println(string);
        }
    }
}
