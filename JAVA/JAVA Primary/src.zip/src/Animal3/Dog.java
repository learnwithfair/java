package Animal3;

public class Dog {

    public void display() {
    System.out.println("This is Dog Class in the  Package of the Animal 3 ");
    }
}
