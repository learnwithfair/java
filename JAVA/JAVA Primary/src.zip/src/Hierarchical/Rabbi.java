package Hierarchical;
public class Rabbi extends Man {
    int id;
    Rabbi(String name, String colour, int id) {
        super(name, colour);
        this.id = id;
    }
    @Override
    void display() {
        super.display();
        System.out.println("ID : " + id);
    }
}
