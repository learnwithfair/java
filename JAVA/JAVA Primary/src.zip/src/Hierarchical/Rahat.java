package Hierarchical;

public class Rahat extends Man {

    String heir;

    Rahat(String name, String colour, String heir) {
        super(name, colour);
        this.heir = heir;
    }

    @Override
    void display() {
        super.display();
        System.out.println("Heir Colour : " + heir);
    }
}
