package Hierarchical;
public class Test {
    public static void main(String[] args) {
        Rabbi ob1 = new Rabbi("Rabbi", "White", 203);
        Rahat ob2 = new Rahat("Rahat", "White", "Black");
        ob1.display();
        ob2.display();
    }
}
