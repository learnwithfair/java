package Hierarchical;
public class Man {
    String name, colour;
    Man(String name, String colour) {
        this.name = name;
        this.colour = colour;
    }
    void display() {
        System.out.println("Name : " + name);
        System.out.println("Colour : " + colour);
    }
}
