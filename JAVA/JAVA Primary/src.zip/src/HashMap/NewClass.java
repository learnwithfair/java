package HashMap;

import java.util.HashMap;

public class NewClass {

    public static void main(String[] args) {
        HashMap<Integer, String> str = new HashMap<Integer, String>();
        str.put(101, "Rahatul Islam");
        str.put(102, "Anisul Islam");
        str.put(102, "Sumon Roy");
        str.put(103, "Sohanur Rahman");
        System.out.println("HashMap : " + str);
        System.out.println("Size of HashMap is : " + str.size());
        System.out.println("Index of 102 is " + str.get(102));
        System.out.println("HashMap is Empty : " + str.isEmpty());
        str.replace(102, "Anisul Islam");
        System.out.println("After Replaceing Sumon Roy by Anisul Islam  HashMap : " + str);
        str.remove(103);
        System.out.println("After Removing Sohanur Rahman HashMap : " + str);
        str.clear();
        System.out.println("After Clear HashMap : " + str);
    }
}
