package File;

import java.io.File;
import java.util.Formatter;
import java.util.Scanner;

public class fileDemo1 {

    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        try {
            //Make Directory
            File dir = new File("D:/Java Program/AnisulIslam/src/File/Person");
            dir.mkdir();
            //File Ctrate
            File file1 = new File(dir.getAbsolutePath() + "/Student.txt");
            file1.createNewFile();
            File file2 = new File(dir.getAbsolutePath() + "/Teacher.txt");
            file2.createNewFile();
            System.out.println("Directory & Files has been Created");
            System.out.println("\n\nWrite File:");
            Formatter formatter1 = new Formatter(file1.getAbsolutePath());
            Formatter formatter2 = new Formatter(file2.getAbsolutePath());
            formatter1.format("  ID\tName\r\n--------------\r\n");
            System.out.printf("How many Student  : ");
            int n = Rahat.nextInt();
            System.out.printf("Enter ID & Name : \n");
            for (int i = 0; i < n; i++) {
                System.out.printf("%d. ID : ", i + 1);
                String id = Rahat.next();
                System.out.printf("%d. Name  : ", i + 1);
                String name = Rahat.next();
                formatter1.format("  %s\t%s\r\n", id, name);
            }
            formatter1.close();
            System.out.println("\n\nRead File:\n");
            Scanner input1 = new Scanner(file1);
            Scanner input2 = new Scanner(file1);
            while (input1.hasNext()) {
                System.out.println(input1.nextLine());
            }
            input1.close();
            while (input2.hasNext()) {
                formatter2.format("%s", input2.nextLine());
                formatter2.format("\r\n");
            }
            input2.close();
            formatter2.close();

        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println("\nValues are Succesfully Stored in Teacher Class");
    }
}
