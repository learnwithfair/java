package SingleInheritance;

public class Test {

    public static void main(String[] args) {

        Rohim ob = new Rohim("Rahatul Islam", 22, "Black");
        Person ob1 = new Person("Sohanur Islam", 24);
        ob.display();
        ob1.display();
    }
}
