package SingleInheritance;

public class Rohim extends Person {

    String heircolour;

    Rohim(String name, int age, String heircolour) {
        super(name, age);
        this.heircolour = heircolour;
    }

    @Override
    void display() {
        super.display();
        System.out.println("Heri Colour : " + heircolour);
    }
}
