package Polymorphism;

public class Test {

    public static void main(String[] args) {
        Shape[] ob = new Shape[3];
        ob[0] = new Shape();
        ob[1] = new Rectangle(10, 20);
        ob[2] = new Triangle(10, 20);
        for (int i = 0; i < 3; i++) {
            System.out.println(ob[i].area());
        }
    }
}
