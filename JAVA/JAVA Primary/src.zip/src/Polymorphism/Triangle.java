package Polymorphism;

public class Triangle extends Shape {

    Triangle(double dim1, double dim2) {
        super.setValue(dim1, dim2);
    }

    @Override
    double area() {
        System.out.print("Area of Triangle : ");
        return (0.5 * dim1 * dim2);
    }
}
