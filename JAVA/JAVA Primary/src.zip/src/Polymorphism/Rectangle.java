package Polymorphism;

public class Rectangle extends Shape {

    Rectangle(double dim1, double dim2) {
        super.setValue(dim1, dim2);
    }

    @Override
    double area() {
        System.out.print("Area of Rectangle : ");
        return (dim1 * dim2);
    }
}
