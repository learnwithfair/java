package MathClass;

import static java.lang.Math.acos;
import static java.lang.Math.asin;
import java.util.Scanner;

public class Math2 {

    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        System.out.printf("Enter Frist Number  : ");
        int x = Rahat.nextInt();
        System.out.printf("Enter Second Number  : ");
        int y = Rahat.nextInt();
        System.out.printf("Enter Value of arc sin/cos : ");
        int arc = Rahat.nextInt();
        System.out.println("Value of Maximum : " + Math.max(x, y));
        System.out.println("Value of Minimum : " + Math.min(x, y));
        System.out.println("Absulate Value " + Math.abs(x));
        System.out.println("Value of X to the Power Y : " + Math.pow(x, y));
        System.out.println("Value of sqrt(X)  : " + Math.sqrt(x));
        System.out.println("Value of e to the power x : " + Math.exp(x));
        double num = asin(arc) * (180 / Math.PI);
        System.out.println("Value of arc sin : " + num);
        double num2 = acos(arc) * (180 / Math.PI);
        System.out.println("Value of arc cos : " + num2);
    }
}
