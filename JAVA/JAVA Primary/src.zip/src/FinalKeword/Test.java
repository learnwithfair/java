package FinalKeword;

import java.util.Scanner;

public class Test {

    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        System.out.printf("Enter Hostel Fee : ");
        int hostel_fee = Rahat.nextInt();
        University ob = new University(hostel_fee);
        ob.display();
    }
}
