package FinalKeword;
public class University {
    final String UNIVERSITY_NAME = "PUST";
    final int hostel_fee;
    static final int admission_fee;
    University(int hostel_fee) {
        this.hostel_fee = hostel_fee;
    }
    static {
        admission_fee = 3200;
    }
    void display() {
        System.out.println("University Name : " + UNIVERSITY_NAME);
        System.out.println("Admission Fee : " + admission_fee);
        System.out.println("Hostel Fee : " + hostel_fee);
    }
}
