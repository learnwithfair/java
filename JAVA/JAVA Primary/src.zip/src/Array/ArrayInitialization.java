package Array;
import java.util.Scanner;
public class ArrayInitialization {
    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        System.out.printf("How many number  : ");
        int n = Rahat.nextInt();
        int[] array = new int[n];
        double[] array2 = new double[n];
        System.out.printf("Enter Elements  : ");
        for (int i = 0; i < n; i++) {
            array2[i] = Rahat.nextDouble();
            array[i] =(int) array2[i];
        }
        System.out.printf("Interger Type Array  : ");
        for (int d : array) {
            System.out.print(" " + d);
        }
        System.out.printf("\nDouble Type Array  : ");
        for (double d : array2) {
            System.out.print(" " + d);
        }
        System.out.println();
    }
}
