package Array;

import java.util.LinkedList;
import java.util.Scanner;
public class LinkedListInitialization {

    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        int[] array = new int[20];
        LinkedList<Integer> number = new LinkedList<>();
        System.out.printf("How many number  : ");
        int n = Rahat.nextInt();
        System.out.printf("Enter elements : ");
        for (int i = 0; i < n; i++) {
            array[i] = Rahat.nextInt();
            number.add(i, array[i]);
        }
        System.out.println("\nLinked List : " + number);
    }
}
