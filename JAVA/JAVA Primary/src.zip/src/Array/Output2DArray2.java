package Array;

public class Output2DArray2 {

    public static void main(String[] args) {
        int[][] array = new int[4][];
        array[0] = new int[1];
        array[1] = new int[2];
        array[2] = new int[3];
        array[3] = new int[4];
        int count = 0;
        System.out.printf("Pattern of Output is  : \n");
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j <= i; j++) {
                array[i][j] = count;
                System.out.printf(" %d", array[i][j]);
                count++;
            }
            System.out.println();
        }
    }
}
