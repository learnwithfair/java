package Array;

import java.util.Collections;
import java.util.LinkedList;

public class LinkList {

    public static void main(String[] args) {
        LinkedList<Integer> number = new LinkedList<Integer>();
        LinkedList<Integer> number2 = new LinkedList<Integer>();
        LinkedList<Integer> number3 = new LinkedList<Integer>();
        number.add(56);
        number.add(32);
        number.add(67);
        number.add(23);
        number.add(2, 99);
        int size = number.size();
        System.out.println("Linked List 1 : " + number);
        System.out.println("Size of Linked List 1 : " + size);
        number2.addAll(number);
        number3.addAll(number);
        System.out.println("After Add All Element in the Linked List 2 : " + number2);
        boolean equal = number.equals(number2);
        System.out.println("Linked List 1 & Array List 2 are same : " + equal);
        number.remove(3);
        System.out.println("After Removing index of 3 in the Linked List 1 :  " + number);
        boolean cont = number.contains(23);
        System.out.println("Contains  value of 23 in the Linked List 1 : " + cont);
        int index = number.indexOf(23);
        System.out.println("Index of Contain value 23: " + index);
        number.set(2, 88);
        System.out.println("After Replace value of 88 in index 2 in the Linked List 1 :  " + number);
        int g = number.get(2);
        System.out.println("Value of 2 number index in the Linked List 1 : " + g);
        number2.removeAll(number2);
        System.out.println("After Remove All Element in the Linked List 2 : " + number2);
        boolean empty = number2.isEmpty();
        System.out.println("Linked List 2 is Empty : " + empty);
        number.clear();
        System.out.println("After Clear Element in the Linked List 1 : " + number2);
        number.addAll(number3);
        Collections.sort(number);
        System.out.println("After Ascending Order of Linked List 1 : " + number);
        Collections.sort(number, Collections.reverseOrder());
        System.out.println("After Descending Order of Linked List 1 : " + number);
    }
}
