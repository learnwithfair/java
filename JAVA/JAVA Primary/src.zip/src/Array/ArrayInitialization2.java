package Array;

public class ArrayInitialization2 {

    public static void main(String[] args) {
        int[] array = {2, 4, 3, 2, 9};
        System.out.println("Size of array : " + array.length);
        System.out.printf("Array List : ");
        for (int i : array) {
            System.out.print(" " + i);
        }
        System.out.println();
    }
}
