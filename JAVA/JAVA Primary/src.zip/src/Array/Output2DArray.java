package Array;

import java.util.Scanner;

public class Output2DArray {

    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        System.out.printf("Enter Row : ");
        int row = Rahat.nextInt();
        System.out.printf("Enter Column : ");
        int col = Rahat.nextInt();
        int[][] array = new int[row][col];
        int count = 0;
        System.out.printf("Pattern of Output is  : \n");
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                array[i][j]=count;
                System.out.printf(" %d",array[i][j]);
                count++;
            }
            System.out.println();
        }
    }
}
