package Array;

import java.util.Arrays;
import java.util.Scanner;

public class ArraySorting {
    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        System.out.printf("How many number  : ");
        int n = Rahat.nextInt();
        int[] array = new int[n];
        System.out.printf("Enter Elements : ");
        for (int i = 0; i < n; i++) {
            array[i] = Rahat.nextInt();
        }
        System.out.printf("Array List : ");
        for (int i : array) {
            System.out.printf(" %d", i);
        }
        Arrays.sort(array);
        System.out.printf("\nAfter Sorting / Ascending array List  : ");
        for (int i : array) {
            System.out.print(" " + i);
        }
        System.out.print("\nDescending array List : ");
        for (int i = n - 1; i >= 0; i--) {
            System.out.print(" " + array[i]);
        }
        System.out.println();
    }
}
