
package anisulislam;

import java.util.ArrayList;

public class ArrayListAllMethod {
    public static void main(String[] args) {
        ArrayList<Integer> number = new ArrayList<>();
        ArrayList<Integer> number2 = new ArrayList<>();
        ArrayList<Integer> number3 = new ArrayList<>();
        number.add(5);
        number.add(4);
        number.add(3);
        number.add(9);
        number.add(2);
        number.add(5,6);
        System.out.print("Using For Each Loop Array List : ");
        for (int integer : number) {
            System.out.print(" "+integer);
        }
        System.out.println();
        System.out.println("Using For Loop Array List : Not Possible");
        //for (int i=0 ;i<number.size();i++) {
           // System.out.print(" "+number[i]);
       // }
        
        System.out.print("Using Iterator Array List : ");
        java.util.Iterator<Integer> itr = number.iterator();
      while(itr.hasNext())
          {
              System.out.print(" "+itr.next());
         }
        System.out.println();
        System.out.println("Size Of Array List : "+number.size());
        System.out.println("Array List : "+number);
        number.remove(4);
        System.out.println("After Removing Array List : "+number);
        boolean b = number.contains(9);
        System.out.println("Value of 9 Contains in Array List : "+b);
        int n = number.indexOf(6);
        System.out.println("Index of 6 is : "+n);
        number.set(4, 88);
        System.out.println("After Set Value Array List : "+number);
        int p =number.get(2);
        System.out.println("2 number Position Value Is : "+p);
        number2.addAll(number);
        System.out.println("Number 2 : "+number2);
        boolean check= number.equals(number2);
        System.out.println("Number = Number2 : "+check);
        number2.clear();
        System.out.println("Number 2 : "+number2);
        boolean result = number3.isEmpty();
        System.out.println("Number 3 Empty : "+result);
        number.removeAll(number);
        System.out.println("Value of Number : "+number);
    }
}
