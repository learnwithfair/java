
package anisulislam;

import java.util.ArrayList;
import java.util.Collections;


public class ArrayListSort {
    public static void main(String[] args) {
        ArrayList<Integer> number = new ArrayList<>();
        number.add(34);
        number.add(45);
        number.add(32);
        number.add(87);
        number.add(23);
        number.add(63);
        number.add(98);
        System.out.println("Array List : "+number);
        Collections.sort(number);
         System.out.println("After Sort Array List : "+number);
        Collections.sort(number,Collections.reverseOrder());
         System.out.println("Descending Array List : "+number);

        
        
    }
}
