
package anisulislam;

import java.util.ArrayList;

public class Iterator {
    public static void main(String[] args) {
       
        ArrayList<Integer> num=new ArrayList <> ();
        int n=num.size();
        System.out.println("Size of array : "+n);
        num.add(34);
        num.add(35);
        num.add(76);
        num.add(38);
        num.add(43);
        num.add(23);
        java.util.Iterator<Integer> itr = num.iterator();
        System.out.printf("array List : ");
        while(itr.hasNext())
        {
            System.out.print(" "+itr.next());
        }
        System.out.println();
    }
}

   
