package anisulislam;
import java.util.Scanner;

public class PalindromeNumber {
    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        System.out.printf("Enter any number  : ");
        int num=Rahat.nextInt();
        int n=num;
        int[] a=new int[20];
        int sum=0;
        while(num!=0)
        {
            int rem =num%10;
            sum=sum*10+rem;
            num=num/10;
        }
        if (n==sum)
            System.out.printf("Palindrome Number.  \n");
        else
            System.out.printf("Not Palindrome Number.  \n");
        
    }
}
