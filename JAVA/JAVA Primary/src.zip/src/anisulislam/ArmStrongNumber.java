
package anisulislam;

import java.util.Scanner;

public class ArmStrongNumber {
    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        System.out.printf("Enter any number  : ");
        int num=Rahat.nextInt();
        int sum=0;
        int n=num;
        while(num!=0)
        {
            int rem=num%10;
            sum=sum+rem*rem*rem;
            num=num/10;
        }
        if(n==sum)
        
            System.out.printf("This number is Armstrong number\n");
        else 
            System.out.printf("This number is Not Armstrong number\n");
        
    }
}
//output 153
