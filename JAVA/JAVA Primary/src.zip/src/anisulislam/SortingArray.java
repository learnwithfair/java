
package anisulislam;

import java.util.Arrays;
import java.util.Scanner;


public class SortingArray {
    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
       
        System.out.printf("How many number  : ");
        int num=Rahat.nextInt();
         int[] a=new int [num];
        System.out.printf("Enter Elements : ");
        for (int i = 0; i < num; i++) {
            a[i]=Rahat.nextInt();
        }
        System.out.printf("Array List : ");
        for (int i = 0; i < num; i++) {
            System.out.printf("%d ",a[i]);
        }
        System.out.printf("\nAfter Sorting/ Increasing Array List : ");
        Arrays.sort(a);
        for (int i : a) {
            System.out.print(" "+i);
        }
        System.out.println();
        System.out.printf("\nAfter Decending Array list : ");
        
        for (int i =a.length-1;i>=0;i--) {
            System.out.printf("%d ",a[i]);
        }
        System.out.println();
    }
}
