
package anisulislam;
import java.util.Scanner;

public class ReverseNumber {
    public static void main(String[] args)
    {
        Scanner Rahat=new Scanner (System.in);
        System.out.printf("Enter any number : ");
        int num=Rahat.nextInt();
        System.out.printf("Reverse Number is  : ");
        while(num!=0)
        {
            int rem = num%10;
            System.out.printf("%d",rem);
            num=num/10;
        }
        System.out.println();
    }
}
