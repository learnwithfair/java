
package anisulislam;

import java.util.Scanner;

public class ForEachLoop {
    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
       
        System.out.printf("How many numbwer  : ");
        int n=Rahat.nextInt();
         double[] a=new double [n];
        System.out.printf("Enter Elements : ");
        for (int i = 0; i < n; i++) {
            a[i]=Rahat.nextDouble();
            
        }
        System.out.printf("Array List : ");
        for (double d : a) {
            System.out.printf("%.2f ",d);
        }
        System.out.println();
    }
}
