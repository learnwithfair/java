
package anisulislam;

import java.util.ArrayList;
public class Iterator2 {
    public static void main(String[] args) {
        ArrayList<Integer> number = new ArrayList<Integer> ();
        number.add(9);
        number.add(6);
        number.add(4);
        number.add(8);
        number.add(2);
        java.util.Iterator<Integer> itr = number.iterator();
        System.out.printf("Array List : ");
        while(itr.hasNext())
        {
            System.out.print(" "+itr.next());
        }
        System.out.println();
    }
}
