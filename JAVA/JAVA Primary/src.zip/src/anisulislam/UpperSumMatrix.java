
package anisulislam;

import java.util.Scanner;

public class UpperSumMatrix {
    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        int[][] A=new int [20][20];
        System.out.printf("Enter Row number : ");
        int row=Rahat.nextInt();
        
        System.out.printf("Enter Column number : ");
        int col=Rahat.nextInt();
        while(row!=col)
        {
            System.out.printf("Please Enter Row & Column number is Same for Upper Matrix.\n");
            System.out.printf("Enter Column number : ");
        col=Rahat.nextInt();
        }
        System.out.printf("Enter Elements : \n");
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                System.out.printf("A[%d][%d]  : ",i,j);
                A[i][j]=Rahat.nextInt();
            }
        }
        System.out.printf("\nA Matrix  : \n");
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                System.out.printf("%d ",A[i][j]);
            }
            System.out.println();
        }
        int sum=0;
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                if(i<j)
                    sum=sum+A[i][j];
            }
        }
        System.out.printf("\nSum Of Upper Matrix is  : %d\n",sum);
    }
}
