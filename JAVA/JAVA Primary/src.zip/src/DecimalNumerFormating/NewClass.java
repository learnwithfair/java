package DecimalNumerFormating;

import java.text.DecimalFormat;

public class NewClass {

    public static void main(String[] args) {
        double num = 835.234343;
        DecimalFormat ob = new DecimalFormat("0.00");
        System.out.println("Num : " + ob.format(num));

    }
}
