package Operator;

import java.util.Scanner;

public class UnarryOperator {

    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        System.out.printf("Enter any number  : ");
        int num = Rahat.nextInt();
        int num2 = -num;
        int num3 = +num;
        System.out.printf("Value of Unary Minus is (-)%d = %d\n", num, num2);
        System.out.printf("Value of Unary Plus is (+)%d = %d\n", num, num3);
    }
}
