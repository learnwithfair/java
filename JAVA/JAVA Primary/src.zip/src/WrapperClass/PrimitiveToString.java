package WrapperClass;

public class PrimitiveToString {
    public static void main(String[] args) {
        int x1=20;
        String y1=Integer.toString(x1);
        System.out.println("Y1 : "+y1);
        double x2=203.32;
        String y2=Double.toString(x2);
        System.out.println("Y2 : "+y2);
    }
 
}
