package WrapperClass;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class TimeDemo1 {
    public static void main(String[] args) {
        LocalTime time=LocalTime.now();
        DateTimeFormatter t=DateTimeFormatter.ofPattern("hh:mm:ss");
        String currentTime=time.format(t);
        System.out.println("Now, Today Time is : "+currentTime);
    }
}
