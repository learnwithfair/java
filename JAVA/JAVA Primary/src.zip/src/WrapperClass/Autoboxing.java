package WrapperClass;

public class Autoboxing {
    public static void main(String[] args) {
        int x = 20;
        Integer y1 = Integer.valueOf(x);
        System.out.println("Value of Y1 : " + y1);
        Integer y2 = x;
        System.out.println("Value of Y2 : " + y2);
    }
}
