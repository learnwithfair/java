package WrapperClass;

import java.util.Random;
import java.util.Scanner;

public class RandomNumber {

    public static void main(String[] args) {
        Scanner Rahat = new Scanner(System.in);
        while (true) {
            System.out.printf("\n\nEnter Guess Number 2 to 9 : ");
            int n = Rahat.nextInt();
            Random rand = new Random();
            int randomNumber = rand.nextInt(7) + 2;
            if (n == randomNumber) {
                System.out.println("You have won the Game");
            } else {
                System.out.println("You loss. Please try again.");
                System.out.println("Random number has " + randomNumber);
            }
        }
    }
}
