
package WrapperClass;
public class Unboxing {
    public static void main(String[] args) {
        Integer x=new Integer(20);
        int y=Integer.valueOf(x);
        System.out.println("Y : "+y);
        int y1=x.intValue();
        System.out.println("Y2 : "+y1);
        int y2=x;
        System.out.println("Y2 : "+y2);
    }
}
