package WrapperClass;

public class StringToPerimitive {

    public static void main(String[] args) {
        String x = "324";
        int y1 = Integer.valueOf(x);
        System.out.println("Y1 : " + y1);
        //Or
        int y2 = Integer.parseInt(x);
        System.out.println("Y2 : " + y2);
    }
}
