package WrapperClass;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
public class DateDemo1 {
    public static void main(String[] args) {
        Date date=new Date();
        DateFormat d=new SimpleDateFormat("dd/MM/YYYY");
        String currentDate=d.format(date);
        System.out.println("Today Date is : "+currentDate);
    }
}
