package MultipleInheritance;

public interface B extends A {

    @Override
    public void foo();
}
