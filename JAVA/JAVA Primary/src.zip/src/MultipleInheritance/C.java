package MultipleInheritance;

public interface C extends A {

    @Override
    public void foo();
}
