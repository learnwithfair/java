package MultipleInheritance;

public class D implements B, C {

    @Override
    public void foo() {
        System.out.println("Hello Rahat");
    }
}
