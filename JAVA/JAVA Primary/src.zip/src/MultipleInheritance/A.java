package MultipleInheritance;

public interface A {

    public void foo();
}
