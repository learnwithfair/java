package MultipleInheritance;

public class Test {

    public static void main(String[] args) {
        A ob;
        ob = new D();
        ob.foo();
    }
}
