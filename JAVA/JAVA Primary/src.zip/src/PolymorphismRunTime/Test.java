package PolymorphismRunTime;

public class Test {

    public static void main(String[] args) {
        Person ob = new Person("Rahatul Islam", 21);
        ob.display();
        ob = new Student("Sohsnur Islam", "Student", 22);
        ob.display();
    }
}
