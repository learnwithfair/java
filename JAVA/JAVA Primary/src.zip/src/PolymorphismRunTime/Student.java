package PolymorphismRunTime;

public class Student extends Person {

    String qualification;

    Student(String name, String qualification, int age) {
        super(name, age);
        this.qualification = qualification;
    }

    @Override
    void display() {
        super.display();
        System.out.println("Qualification : " + qualification);
    }
}
