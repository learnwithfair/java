package FinalMethod;

public class Student extends Teacher {

    /*void display1()//Can't be Override
    but it can be inherite.
    {
        System.out.println("I am a  Student of ICE.");
    }*/
    void display2() {
        System.out.println("I am a  Student of ICE.");
    }
}
