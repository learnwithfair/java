package FinalMethod;

public class Test {

    public static void main(String[] args) {
        System.out.println("Teacher Class : ");
        Teacher ob1 = new Teacher();
        ob1.display1();
        System.out.println("Student Class : ");
        Student ob2 = new Student();
        ob2.display1();
        ob2.display2();
    }
}
