package FinalMethod;

 public class Teacher {

    final void display1() {
        System.out.println("I am a English Teacher.");
    }
}
