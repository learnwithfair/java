package HashSet;

import java.util.HashSet;

public class NewClass {

    public static void main(String[] args) {
        HashSet<Integer> number = new HashSet<Integer>();
        number.add(23);
        number.add(43);
        number.add(3);
        number.add(30);
        number.add(65);
        number.add(65);//Not Count
        number.add(34);
        System.out.println("List of HashSet : " + number);
        System.out.println("Size of HashSet is : " + number.size());
        System.out.println("Cotains value of 65 : " + number.contains(65));
        System.out.println("HashSet is Empty : " + number.isEmpty());
        number.remove(43);
        System.out.println("After remove value of 43 then HashSet is : " + number);
        number.clear();
        System.out.println("After Clear HashSet : " + number);
    }
}
